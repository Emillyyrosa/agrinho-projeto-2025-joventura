let caminhao;
let estradaY = 0; // Posição Y da estrada para criar o efeito de rolagem
let velocidadeJogo = 5; // Velocidade inicial do jogo
let velocidadeMaxima = 12; // Velocidade máxima que o jogo pode atingir

let oportunidades = [];
let obstaculos = [];
let prosperidade = 0;

let gameState = 'start'; // 'start', 'playing', 'gameOver'

// --- Imagens (Recomendado para um visual melhor) ---
// Se for usar imagens, descomente estas linhas e coloque os caminhos corretos
// let imgCaminhao;
// let imgMaleta;
// let imgCarroObstaculo;

// function preload() {
//   // Carregue suas imagens aqui (coloque os arquivos na mesma pasta do sketch.js)
//   // imgCaminhao = loadImage('caminhao.png');
//   // imgMaleta = loadImage('maleta.png');
//   // imgCarroObstaculo = loadImage('carro.png');
// }

function setup() {
  createCanvas(400, 600); // Tamanho fixo para melhor controle do layout
  caminhao = new Caminhao();
  frameRate(60);
  textAlign(CENTER, CENTER);
  rectMode(CENTER); // Facilita o posicionamento de retângulos pelo centro
}

function draw() {
  if (gameState === 'start') {
    drawStartScreen();
  } else if (gameState === 'playing') {
    drawPlayingState();
  } else if (gameState === 'gameOver') {
    drawGameOverScreen();
  }
}

function drawStartScreen() {
  background(135, 206, 235); // Céu azul
  desenhaEstrada(0.1); // Estrada quase parada para tela de início

  fill(0, 100, 0); // Verde escuro
  textSize(40);
  text('SOJAVENTURE', width / 2, height / 2 - 80);
  textSize(25);
  text('Da Roça à Riqueza', width / 2, height / 2 - 30);

  fill(0);
  textSize(20);
  text('Desvie de obstáculos e colete maletas!', width / 2, height / 2 + 50);
  text('Pressione ESPAÇO para começar', width / 2, height / 2 + 100);
}

function drawPlayingState() {
  background(135, 206, 235); // Céu azul

  // Aumenta a velocidade gradualmente
  velocidadeJogo = min(velocidadeMaxima, velocidadeJogo + 0.0005);

  // Desenha a estrada com a velocidade atual
  desenhaEstrada(velocidadeJogo);

  // Atualiza e mostra o caminhão
  caminhao.update();
  caminhao.show();

  // Gera novas oportunidades
  if (frameCount % floor(map(velocidadeJogo, 5, velocidadeMaxima, 90, 40)) === 0) { // Mais oportunidades com mais velocidade
    oportunidades.push(new Oportunidade());
  }

  // Gera novos obstáculos
  if (frameCount % floor(map(velocidadeJogo, 5, velocidadeMaxima, 70, 30)) === 0) { // Mais obstáculos com mais velocidade
    obstaculos.push(new Obstaculo());
  }

  // Atualiza e mostra oportunidades
  for (let i = oportunidades.length - 1; i >= 0; i--) {
    oportunidades[i].update();
    oportunidades[i].show();

    if (caminhao.colide(oportunidades[i])) {
      prosperidade += oportunidades[i].valor;
      oportunidades.splice(i, 1); // Remove maleta coletada
    } else if (oportunidades[i].offscreen()) {
      oportunidades.splice(i, 1); // Remove maleta fora da tela
    }
  }

  // Atualiza e mostra obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].update();
    obstaculos[i].show();

    if (caminhao.colide(obstaculos[i])) {
      gameState = 'gameOver'; // Colisão = Game Over
    } else if (obstaculos[i].offscreen()) {
      obstaculos.splice(i, 1); // Remove obstáculo fora da tela
    }
  }

  // Exibe a prosperidade
  fill(0);
  textSize(24);
  text('Prosperidade: ' + prosperidade, width / 2, 30);
  textSize(16);
  text('Velocidade: ' + nf(velocidadeJogo, 0, 1), width / 2, 55); // Mostra velocidade com 1 casa decimal
}

function drawGameOverScreen() {
  background(255, 0, 0); // Fundo vermelho para Game Over
  fill(255);
  textSize(50);
  text('GAME OVER!', width / 2, height / 2 - 50);
  textSize(30);
  text('Prosperidade Final: ' + prosperidade, width / 2, height / 2 + 10);
  textSize(20);
  text('Pressione ESPAÇO para jogar novamente', width / 2, height / 2 + 70);
}

function keyPressed() {
  if (key === ' ' || key === 'ArrowUp') { // Barra de espaço ou Seta para cima
    if (gameState === 'start' || gameState === 'gameOver') {
      resetGame();
      gameState = 'playing';
    }
  }
}

function resetGame() {
  prosperidade = 0;
  velocidadeJogo = 5;
  oportunidades = [];
  obstaculos = [];
  caminhao = new Caminhao(); // Cria um novo caminhão
  estradaY = 0;
}

// --- CLASSE CAMINHÃO ---
class Caminhao {
  constructor() {
    this.w = 60; // Largura do caminhão
    this.h = 100; // Altura do caminhão
    this.x = width / 2; // Começa no centro horizontal
    this.y = height - this.h / 2 - 20; // Perto da parte inferior da tela
    this.velocidadeLateral = 6;
  }

  show() {
    // if (imgCaminhao) {
    //   image(imgCaminhao, this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
    // } else {
    // Desenho básico do caminhão (corpo e rodas)
    fill(139, 69, 19); // Cor de soja (marrom)
    rect(this.x, this.y - 20, this.w, this.h * 0.7); // Carroceria

    fill(100, 50, 0); // Cabine marrom mais escura
    rect(this.x, this.y - this.h * 0.45, this.w * 0.8, this.h * 0.4); // Cabine

    // Rodas
    fill(50);
    ellipse(this.x - this.w / 2 + 10, this.y + this.h / 2 - 10, 15, 15); // Roda traseira esquerda
    ellipse(this.x + this.w / 2 - 10, this.y + this.h / 2 - 10, 15, 15); // Roda traseira direita
    ellipse(this.x - this.w / 2 + 10, this.y - this.h / 2 + 20, 15, 15); // Roda dianteira esquerda
    ellipse(this.x + this.w / 2 - 10, this.y - this.h / 2 + 20, 15, 15); // Roda dianteira direita

    // Luzes da cabine (pixel art like)
    fill(255, 255, 0); // Amarelo
    rect(this.x - 15, this.y - this.h * 0.45 - 15, 5, 5);
    rect(this.x + 15, this.y - this.h * 0.45 - 15, 5, 5);
    // }
  }

  update() {
    // Controle com as setas do teclado
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidadeLateral;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidadeLateral;
    }

    // Limita o caminhão dentro da tela
    this.x = constrain(this.x, this.w / 2, width - this.w / 2);
  }

  colide(objeto) {
    // Adaptação da colisão de retângulo com retângulo
    // (Lembre-se que rect(x,y,w,h) é desenhado do centro)
    return abs(this.x - objeto.x) * 2 < (this.w + objeto.w) &&
           abs(this.y - objeto.y) * 2 < (this.h + objeto.h);
  }
}

// --- CLASSE OPORTUNIDADE (MALETA) ---
class Oportunidade {
  constructor() {
    this.w = 30; // Largura da maleta
    this.h = 25; // Altura da maleta
    this.x = random(this.w / 2, width - this.w / 2);
    this.y = -this.h / 2; // Começa acima da tela
    this.velocidade = velocidadeJogo; // Velocidade da maleta
    this.valor = floor(random(10, 25)); // Valor de prosperidade da maleta
  }

  show() {
    // if (imgMaleta) {
    //   image(imgMaleta, this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
    // } else {
    // Desenho básico da maleta
    fill(200, 180, 0); // Dourado
    rect(this.x, this.y, this.w, this.h, 5); // Corpo da maleta

    fill(150, 130, 0); // Alça mais escura
    rect(this.x, this.y - this.h / 2, this.w * 0.6, 5);
    // }
  }

  update() {
    this.y += this.velocidade;
  }

  offscreen() {
    return this.y > height + this.h / 2;
  }
}

// --- CLASSE OBSTÁCULO ---
class Obstaculo {
  constructor() {
    this.w = random(40, 70); // Largura variável do obstáculo
    this.h = random(30, 80); // Altura variável do obstáculo
    this.x = random(this.w / 2, width - this.w / 2);
    this.y = -this.h / 2; // Começa acima da tela
    this.velocidade = velocidadeJogo * random(0.8, 1.2); // Velocidade do obstáculo pode variar um pouco
  }

  show() {
    // if (imgCarroObstaculo) {
    //   image(imgCarroObstaculo, this.x - this.w / 2, this.y - this.h / 2, this.w, this.h);
    // } else {
    // Desenho básico do obstáculo (carros/pedras)
    let tipo = floor(random(2)); // 0 = carro, 1 = pedra

    if (tipo === 0) { // Carro
      fill(random(50, 200), random(50, 200), random(50, 200)); // Cor aleatória
      rect(this.x, this.y, this.w, this.h, 5); // Corpo do carro
      fill(50); // Rodas
      ellipse(this.x - this.w / 4, this.y + this.h / 2 - 5, 10, 10);
      ellipse(this.x + this.w / 4, this.y + this.h / 2 - 5, 10, 10);
      ellipse(this.x - this.w / 4, this.y - this.h / 2 + 5, 10, 10);
      ellipse(this.x + this.w / 4, this.y - this.h / 2 + 5, 10, 10);
    } else { // Pedra
      fill(90, 80, 70); // Cor de pedra
      // Desenha uma forma irregular para a pedra
      beginShape();
      vertex(this.x - this.w / 2, this.y + this.h / 4);
      vertex(this.x - this.w / 4, this.y - this.h / 2);
      vertex(this.x + this.w / 4, this.y - this.h / 2);
      vertex(this.x + this.w / 2, this.y - this.h / 4);
      vertex(this.x + this.w / 4, this.y + this.h / 2);
      vertex(this.x - this.w / 4, this.y + this.h / 2);
      endShape(CLOSE);
    }
    // }
  }

  update() {
    this.y += this.velocidade;
  }

  offscreen() {
    return this.y > height + this.h / 2;
  }
}

// --- FUNÇÃO PARA DESENHAR A ESTRADA ---
function desenhaEstrada(velocidadeAtual) {
  fill(100); // Cor do asfalto
  rect(width / 2, height / 2, width, height); // Estrada preenche a tela

  // Linhas da estrada (efeito de rolagem)
  stroke(255);
  strokeWeight(5);
  // Desenha múltiplas linhas para criar um efeito contínuo
  for (let i = 0; i < height / 50 + 2; i++) { // Mais linhas para cobrir a tela toda
    let y = (estradaY + i * 100) % (height + 100); // Calcula a posição Y de cada linha
    line(width / 2, y - 50, width / 2, y + 50); // Linha central
  }
  estradaY += velocidadeAtual; // Move a estrada
}